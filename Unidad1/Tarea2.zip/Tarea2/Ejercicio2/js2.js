
function manejarEnfoque(elemento) {

    elemento.style.backgroundColor = "lightgray";

    elemento.style.color = 'blue';
}

function restaurarEnfoque(elemento) {

    elemento.style.backgroundColor = 'white';

    elemento.style.color = "black"
}