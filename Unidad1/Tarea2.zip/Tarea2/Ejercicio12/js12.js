function redondear(elemento) {
    elemento.style.borderRadius = '50%';
    elemento.style.border = '5px solid blue';

}

function restaurar(elemento) {
    elemento.style.borderRadius = '0';
    elemento.style.border = '';

}