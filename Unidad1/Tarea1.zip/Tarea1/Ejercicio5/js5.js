function cambiarTamano() {

    const imagen = document.getElementById('imagen');

    imagen.style.width = '100px';
    imagen.style.height = '100px';

}
